import tkinter as tk
import random
from tkinter import messagebox

# Constants
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 600
CAR_WIDTH = 40
CAR_HEIGHT = 80
LANES = [100, 180, 260]  # X positions for 3 lanes
ENEMY_SPEED = 8
PLAYER_SPEED = 20

class RacingGame:
    def __init__(self, root):
        self.root = root
        self.root.title("🏁 Racing Game - Tkinter")
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.root.resizable(False, False)

        # Canvas
        self.canvas = tk.Canvas(self.root, width=WINDOW_WIDTH, height=WINDOW_HEIGHT, bg="gray")
        self.canvas.pack()

        # Draw road lines
        self.road_lines = []
        for i in range(6):
            line = self.canvas.create_rectangle(195, i * 120, 205, i * 120 + 60, fill="white", width=0)
            self.road_lines.append(line)

        # Player Car
        self.player = self.canvas.create_rectangle(180, 480, 180 + CAR_WIDTH, 480 + CAR_HEIGHT, fill="blue", tags="player")

        # Enemy Cars
        self.enemies = []
        for _ in range(3):
            lane = random.choice(LANES)
            y = random.randint(-600, -100)
            enemy = self.canvas.create_rectangle(
                lane, y, lane + CAR_WIDTH, y + CAR_HEIGHT, fill="red", tags="enemy"
            )
            self.enemies.append(enemy)

        # Score
        self.score = 0
        self.score_text = self.canvas.create_text(10, 10, anchor="nw", font=("Arial", 14), fill="white",
                                                  text=f"Score: {self.score}")

        # Key bindings
        self.root.bind("<Left>", self.move_left)
        self.root.bind("<Right>", self.move_right)

        # Start game loop
        self.update_game()

    def move_left(self, event):
        x1, y1, x2, y2 = self.canvas.coords(self.player)
        if x1 > 100:
            self.canvas.move(self.player, -80, 0)

    def move_right(self, event):
        x1, y1, x2, y2 = self.canvas.coords(self.player)
        if x1 < 260:
            self.canvas.move(self.player, 80, 0)

    def update_game(self):
        # Move road lines
        for line in self.road_lines:
            self.canvas.move(line, 0, ENEMY_SPEED)
            if self.canvas.coords(line)[1] > WINDOW_HEIGHT:
                self.canvas.move(line, 0, -WINDOW_HEIGHT)

        # Move enemies
        for enemy in self.enemies:
            self.canvas.move(enemy, 0, ENEMY_SPEED)
            x1, y1, x2, y2 = self.canvas.coords(enemy)
            if y1 > WINDOW_HEIGHT:
                self.score += 1
                self.canvas.itemconfigure(self.score_text, text=f"Score: {self.score}")
                lane = random.choice(LANES)
                self.canvas.coords(enemy, lane, -100, lane + CAR_WIDTH, -100 + CAR_HEIGHT)

            # Check for collision
            if self.check_collision(self.player, enemy):
                self.game_over()
                return

        # Keep looping
        self.root.after(30, self.update_game)

    def check_collision(self, car1, car2):
        x1, y1, x2, y2 = self.canvas.bbox(car1)
        a1, b1, a2, b2 = self.canvas.bbox(car2)
        return not (x2 < a1 or x1 > a2 or y2 < b1 or y1 > b2)

    def game_over(self):
        self.canvas.create_text(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2, text="💥 GAME OVER 💥",
                                font=("Arial", 24, "bold"), fill="yellow")
        messagebox.showinfo("Game Over", f"Your score: {self.score}")
        self.root.destroy()

# Start Game
if __name__ == "__main__":
    root = tk.Tk()
    game = RacingGame(root)
    root.mainloop()
